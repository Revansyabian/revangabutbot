import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
import sqlite3, json, os, time

with open("config.json") as f:
    config = json.load(f)

TOKEN = config["8114502494:AAGEpfA_KRvJ8ku_sG5Fhn17VTbfZd7nw-I"]
ADMIN_ID = config["6977522417"]
ADMIN_GROUP_ID = config.get("admin_group_id", None)

bot = telebot.TeleBot(8114502494:AAGEpfA_KRvJ8ku_sG5Fhn17VTbfZd7nw-I)

# --- Database Setup ---
conn = sqlite3.connect("database.db", check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY)''')
c.execute('''CREATE TABLE IF NOT EXISTS logs (user_id INTEGER, message TEXT, timestamp TEXT)''')
conn.commit()

def add_user(user_id):
    c.execute("INSERT OR IGNORE INTO users VALUES (?)", (user_id,))
    conn.commit()

def log_message(user_id, message):
    c.execute("INSERT INTO logs VALUES (?, ?, ?)", (user_id, message, time.strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()

# --- Keyboard ---
def main_menu(is_admin=False):
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("😎 Menu Gabut", "🧠 AI Mode")
    kb.row("📞 Hubungi CS", "📦 Dummy Top Up")
    if is_admin:
        kb.row("🛠 Admin Panel")
    return kb

# --- Start ---
@bot.message_handler(commands=['start'])
def start(msg):
    user_id = msg.from_user.id
    add_user(user_id)
    log_message(user_id, "/start")

    bot.send_message(user_id, "🔥 Welcome to Bot Gabut Sadis Pro Max\nPilih menu:", reply_markup=main_menu(user_id == ADMIN_ID))

    if ADMIN_GROUP_ID:
        bot.send_message(ADMIN_GROUP_ID, f"👤 New user: {msg.from_user.first_name} ({user_id})")

# --- Menu Gabut ---
@bot.message_handler(func=lambda m: m.text == "😎 Menu Gabut")
def menu_gabut(msg):
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("🎲 Random Number", "😂 Random Joke")
    kb.row("⬅️ Kembali")
    bot.send_message(msg.chat.id, "Menu Gabut Aktif:", reply_markup=kb)

@bot.message_handler(func=lambda m: m.text == "🎲 Random Number")
def random_number(msg):
    from random import randint
    angka = randint(1, 100)
    bot.reply_to(msg, f"Angka hari ini: {angka}")

@bot.message_handler(func=lambda m: m.text == "😂 Random Joke")
def random_joke(msg):
    bot.reply_to(msg, "Kenapa ayam nyebrang jalan? Karena dia gak bisa naik motor 🐔🏍️")

# --- AI Mode Dummy ---
@bot.message_handler(func=lambda m: m.text == "🧠 AI Mode")
def ai_mode(msg):
    bot.send_message(msg.chat.id, "Tanya apa aja, gua jawab sebisanya!")

@bot.message_handler(func=lambda m: m.text not in ["/start", "😎 Menu Gabut", "🧠 AI Mode", "🛠 Admin Panel", "⬅️ Kembali", "📞 Hubungi CS", "📦 Dummy Top Up"])
def ai_or_cs(msg):
    user_id = msg.from_user.id
    log_message(user_id, msg.text)

    # CS Auto Reply
    if "cara top up" in msg.text.lower():
        return bot.reply_to(msg, "Cara top up gampang! Klik 📦 Dummy Top Up lalu pilih nominal.")
    
    if user_id == ADMIN_ID and msg.text.startswith("/broadcast "):
        text = msg.text.replace("/broadcast ", "")
        c.execute("SELECT id FROM users")
        for row in c.fetchall():
            try:
                bot.send_message(row[0], f"📢 Broadcast:\n{text}")
            except:
                continue
        return bot.reply_to(msg, "Broadcast selesai.")

    # AI dummy response
    bot.reply_to(msg, f"Lo nanya: \"{msg.text}\"?\nJawabannya ya... hidup itu pilihan bro 😎")

# --- Top Up Dummy ---
@bot.message_handler(func=lambda m: m.text == "📦 Dummy Top Up")
def dummy_topup(msg):
    kb = ReplyKeyboardMarkup(resize_keyboard=True)
    kb.row("💎 86 UB - Rp3.000", "💎 258 UB - Rp9.000")
    kb.row("💎 514 UB - Rp15.000", "⬅️ Kembali")
    bot.send_message(msg.chat.id, "Pilih nominal top up dummy:", reply_markup=kb)

@bot.message_handler(func=lambda m: m.text.startswith("💎"))
def proses_dummy(msg):
    log_message(msg.from_user.id, f"Top up dummy: {msg.text}")
    bot.reply_to(msg, f"Pesanan {msg.text} sedang diproses... (fiktif ya 🤑)")

# --- CS Contact ---
@bot.message_handler(func=lambda m: m.text == "📞 Hubungi CS")
def cs_contact(msg):
    bot.send_message(msg.chat.id, "Chat Admin via Telegram: @your_admin_username")

# --- Admin Panel ---
@bot.message_handler(func=lambda m: m.text == "🛠 Admin Panel" and m.from_user.id == ADMIN_ID)
def admin_panel(msg):
    bot.send_message(msg.chat.id, "Selamat datang admin!\nGunakan perintah:\n/broadcast isi_pesan\nTotal user: {}".format(c.execute("SELECT COUNT(*) FROM users").fetchone()[0]))

# --- Kembali ---
@bot.message_handler(func=lambda m: m.text == "⬅️ Kembali")
def kembali(msg):
    start(msg)

# --- Run Bot ---
bot.polling()